import React from 'react';
import "./style.css";
import ReactDOM from "react-dom";


let abc1 = () => {

}

let abc3 = () => {

}


export { abc1, abc3 }