let Cardarray5 = [
    {
        h: "Kadhai Paneer",
        p: "This is Kadhai Paneer receipe,which has rich vitamins and good for health"
    }
];
export default Cardarray5;