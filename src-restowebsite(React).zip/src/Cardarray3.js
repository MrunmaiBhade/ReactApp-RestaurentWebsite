let Cardarray3 = [
    {
        img1: require("./images/open-o.png"),
        para1: "Carried nothing on am warrant towards. Polite in of in oh needed itself silent course. Assistance travelling so especially do prosperous appearance mr no celebrated. Wanted easily in my called formed suffer.",
        img2: require("./images/img10.jpeg"),
        head: "Client Name",
        para2: "Profession"
    },
    {
        img1: require("./images/open-o.png"),
        para1: "Carried nothing on am warrant towards. Polite in of in oh needed itself silent course. Assistance travelling so especially do prosperous appearance mr no celebrated. Wanted easily in my called formed suffer.",
        img2: require("./images/img11.jpeg"),
        head: "Client Name",
        para2: "Profession"
    },
    {
        img1: require("./images/open-o.png"),
        para1: "Carried nothing on am warrant towards. Polite in of in oh needed itself silent course. Assistance travelling so especially do prosperous appearance mr no celebrated. Wanted easily in my called formed suffer.",
        img2: require("./images/img12.jpeg"),
        head: "Client Name",
        para2: "Profession"
    },





];
export default Cardarray3;