let Cardarray2 = [
    {
        img: require("./images/img6.jpeg"),
        head: "Full Name",
        para: "Designation",
        img2: require("./images/email.png"),
        img3: require("./images/facebook.png"),
        img4: require("./images/youtube.png")
    },
    {
        img: require("./images/img7.jpeg"),
        head: "Full Name",
        para: "Designation",
        img2: require("./images/email.png"),
        img3: require("./images/facebook.png"),
        img4: require("./images/youtube.png")
    },
    {
        img: require("./images/img8.jpeg"),
        head: "Full Name",
        para: "Designation",
        img2: require("./images/email.png"),
        img3: require("./images/facebook.png"),
        img4: require("./images/youtube.png")
    },
    {
        img: require("./images/img9.jpeg"),
        head: "Full Name",
        para: "Designation",
        img2: require("./images/email.png"),
        img3: require("./images/facebook.png"),
        img4: require("./images/youtube.png")
    },
];
export default Cardarray2;