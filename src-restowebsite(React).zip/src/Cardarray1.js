let Cardarray1 = [
    {
        logo: require("./images/p1.jpeg"),
        head: "Kadhai Paneer",
        img: require("./images/hori.png"),
        para: "Ipsum ipsum clita erat amet dolor justo diam",
        price: "$ 115",
        butn: "Click Me"

    },
    {
        logo: require("./images/p2.jpeg"),
        head: "Kadhai Paneer",
        img: require("./images/hori.png"),
        para: "Ipsum ipsum clita erat amet dolor justo diam",
        price: "$ 115",
        butn: "Click Me"

    },
    {
        logo: require("./images/p3.jpeg"),
        head: "Kadhai Paneer",
        img: require("./images/hori.png"),
        para: "Ipsum ipsum clita erat amet dolor justo diam",
        price: "$ 115",
        butn: "Click Me"

    },
    {
        logo: require("./images/p4.jpeg"),
        head: "Kadhai Paneer",
        img: require("./images/hori.png"),
        para: "Ipsum ipsum clita erat amet dolor justo diam",
        price: "$ 115",
        butn: "Click Me"

    },
    {
        logo: require("./images/p5.jpeg"),
        head: "Kadhai Paneer",
        img: require("./images/hori.png"),
        para: "Ipsum ipsum clita erat amet dolor justo diam",
        price: "$ 115",
        butn: "Click Me"

    },
    {
        logo: require("./images/p6.jpeg"),
        head: "Kadhai Paneer",
        img: require("./images/hori.png"),
        para: "Ipsum ipsum clita erat amet dolor justo diam",
        price: "$ 115",
        butn: "Click Me"

    },
    {
        logo: require("./images/p1.jpeg"),
        head: "Kadhai Paneer",
        img: require("./images/hori.png"),
        para: "Ipsum ipsum clita erat amet dolor justo diam",
        price: "$ 115",
        butn: "Click Me"

    },
    {
        logo: require("./images/p2.jpeg"),
        head: "Kadhai Paneer",
        img: require("./images/hori.png"),
        para: "Ipsum ipsum clita erat amet dolor justo diam",
        price: "$ 115",
        butn: "Click Me"

    },
    {
        logo: require("./images/p3.jpeg"),
        head: "Kadhai Paneer",
        img: require("./images/hori.png"),
        para: "Ipsum ipsum clita erat amet dolor justo diam",
        price: "$ 115",
        butn: "Click Me"

    },
    {
        logo: require("./images/p4.jpeg"),
        head: "Kadhai Paneer",
        img: require("./images/hori.png"),
        para: "Ipsum ipsum clita erat amet dolor justo diam",
        price: "$ 115",
        butn: "Click Me"

    },
    {
        logo: require("./images/p5.jpeg"),
        head: "Kadhai Paneer",
        img: require("./images/hori.png"),
        para: "Ipsum ipsum clita erat amet dolor justo diam",
        price: "$ 115",
        butn: "Click Me"

    },
    {
        logo: require("./images/p6.jpeg"),
        head: "Kadhai Paneer",
        img: require("./images/hori.png"),
        para: "Ipsum ipsum clita erat amet dolor justo diam",
        price: "$ 115",
        butn: "Click Me"

    }


















];
export default Cardarray1