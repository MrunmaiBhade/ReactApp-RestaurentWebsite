let Cardarray4 = [
    {
        img1: require("./images/email.png"),
        img2: require("./images/facebook-app-symbol.png"),
        img3: require("./images/instagram (1).png")
    },
    {
        img1: require("./images/email.png"),
        img2: require("./images/facebook-app-symbol.png"),
        img3: require("./images/instagram (1).png")
    },
    {
        img1: require("./images/email.png"),
        img2: require("./images/facebook-app-symbol.png"),
        img3: require("./images/instagram (1).png")
    },


];
export default Cardarray4;